# Regole essenziali SECAP PRO

## Identità

- Interfaccia pulita, ariosa e professionale.
- Base neutra e blu SECAP usato per azione, selezione, collegamento e focus.
- Area di lavoro, strumento e stato corrente sempre riconoscibili.
- Contenuti e terminologia vicini al lavoro reale: persone, documenti, verbali, commesse e cantieri.

## Gerarchia

- Il contesto precede l’azione.
- Una sola azione principale per ogni gruppo.
- Titoli, spazio e ordine indicano le priorità prima del colore.
- La complessità viene mostrata progressivamente.

## Stati

- Il colore non è mai l’unico segnale.
- Prevedere vuoto, caricamento, contenuto, nessun risultato, errore, non disponibile e completamento quando pertinenti.
- Gli elementi non disponibili devono essere chiari e a basso contrasto, senza sembrare guasti.
- Errori e conferme spiegano sempre cosa è successo e cosa può fare l’utente.

## Interazione e accessibilità

- Target interattivo minimo 44 × 44 px.
- Focus visibile con anello blu.
- Campi sempre accompagnati da un’etichetta comprensibile.
- Niente animazioni decorative continue.
- Rispettare `prefers-reduced-motion`.

## Responsive

- Verificare almeno desktop 1344 × 1000 e mobile 390 × 844.
- Nessuno scorrimento orizzontale dell’intera pagina.
- Tabelle operative trasformate in righe o card su mobile quando necessario.
- Campi e azioni si impilano mantenendo ordine e priorità.
- Tab e filtri possono scorrere orizzontalmente soltanto all’interno del proprio gruppo.

I valori ufficiali sono contenuti in `foundations.tokens.json`. Il foglio `reference/foundations.css` serve come riferimento implementativo e non deve essere copiato integralmente senza valutarne compatibilità e dipendenze.
