# Kit SECAP PRO per l’AI

Questo pacchetto serve a far lavorare un assistente AI su uno strumento isolato, anche quando non può accedere al progetto SECAP PRO completo.

## Come usarlo

1. Crea una copia della cartella dello strumento da aggiornare.
2. Allega all’AI l’intera cartella dello strumento e questo kit completo.
3. Copia dalla guida SECAP PRO l’incarico adatto al lavoro da svolgere.
4. Chiedi all’AI di restituire una nuova cartella completa e funzionante.
5. Conserva intatta la cartella originale fino alla verifica finale.

## Cosa deve restituire l’AI

L’AI deve consegnare:

- l’intera cartella di lavoro aggiornata;
- un file `RIEPILOGO-MODIFICHE.md` nella cartella principale;
- l’elenco dei test e dei controlli eseguiti;
- eventuali decisioni ancora da prendere.

L’AI non deve creare repository, eseguire commit, effettuare push, aprire pull request o tentare il merge nel progetto SECAP PRO.

## Prima di inviare il materiale

Rimuovi credenziali, file `.env`, persone reali, rubriche, trascrizioni, verbali e dati di commessa non destinati alla condivisione. Usa dati dimostrativi negli esempi.

## Contenuto del kit

- `INCARICO-BASE.md`: regole comuni per qualunque intervento.
- `REGOLE-SECAP-PRO.md`: identità, comportamento e responsive.
- `COMPONENTI-E-MODELLI.md`: componenti e strutture da riutilizzare.
- `CHECKLIST-CONSEGNA.md`: controlli prima della restituzione.
- `foundations.tokens.json`: valori ufficiali delle fondamenta.
- `reference/foundations.css`: riferimento implementativo da leggere, non da copiare integralmente senza verifica.
- `incarichi/`: istruzioni specifiche per i diversi lavori.
