# Incarico base per l’AI

Usa tutti i file di questo kit come fonte visiva e implementativa per SECAP PRO. Non inventare valori, componenti o comportamenti alternativi quando il kit contiene già una soluzione pertinente.

Lavora esclusivamente sulla copia dello strumento allegata. Conserva funzioni, flusso, dati, API e formati di uscita esistenti, salvo diversa indicazione esplicita.

## Metodo

1. Analizza prima di modificare.
2. Individua il modello di schermata SECAP PRO più vicino.
3. Riusa fondamenta e componenti esistenti.
4. Applica modifiche piccole e verificabili.
5. Controlla desktop 1344 × 1000 e mobile 390 × 844.
6. Esegui i test disponibili senza chiamate AI reali.

## Consegna

Restituisci l’intera cartella di lavoro aggiornata, non soltanto i file modificati. Aggiungi nella cartella principale `RIEPILOGO-MODIFICHE.md` con:

- cosa è stato cambiato;
- cosa è stato conservato;
- test e controlli eseguiti;
- eventuali problemi o decisioni aperte.

Non creare repository. Non eseguire commit o push. Non aprire pull request. Non tentare il merge nel progetto principale.
