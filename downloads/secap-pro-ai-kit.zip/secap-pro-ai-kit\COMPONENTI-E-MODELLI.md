# Componenti e modelli SECAP PRO

## Componenti da riusare

- Testata globale e contesto dell’area.
- Breadcrumb e navigazione contestuale.
- Pulsanti principale, secondario, discreto e non disponibile.
- Campi, ricerca e suggerimenti.
- Tab per cambiare vista; filtri per restringere risultati.
- Chip per attributi o appartenenze; badge per stati.
- Card area e card strumento.
- Pannello operativo.
- Riga persona, documento o tema.
- Tabella desktop trasformabile in card su mobile.
- Dialogo, caricamento file e avanzamento a passaggi.
- Stati vuoto, caricamento, errore, non disponibile e conferma.

## Modelli di schermata

### Cruscotto

Ordine: orientamento → aree di lavoro → attività aperte.

### Area di lavoro

Ordine: identità dell’area → Strumenti/Membri → disponibilità e accessi.

### Registro

Ordine: contesto compatto → riepilogo → ricerca e filtri → elenco → azione principale.

### Generatore

Ordine: avanzamento → pannelli numerati → revisione → conferma persistente → esito.

### Amministrazione

Ordine: riepilogo → ambiti per tab → ricerca e filtri → righe operative → dialoghi di gestione.

Se una schermata combina più modelli, uno solo deve restare dominante. Non creare nuovi componenti quando uno esistente risolve già lo stesso problema.
