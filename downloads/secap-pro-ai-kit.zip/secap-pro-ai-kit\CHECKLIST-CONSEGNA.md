# Checklist di consegna

Prima di restituire la cartella aggiornata verificare:

- [ ] Area di lavoro, strumento e stato corrente sono riconoscibili.
- [ ] Esiste una sola azione principale per ogni gruppo.
- [ ] Colori, tipografia, spaziature e raggi provengono dal kit.
- [ ] Componenti esistenti sono stati riusati prima di crearne di nuovi.
- [ ] Stati e messaggi sono comprensibili anche senza colore.
- [ ] Vuoto, caricamento, errore, non disponibile e completamento sono gestiti quando pertinenti.
- [ ] Focus, etichette dei campi e target interattivi sono corretti.
- [ ] Desktop 1344 × 1000 è stato controllato.
- [ ] Mobile 390 × 844 è stato controllato.
- [ ] La pagina non presenta scorrimento orizzontale su mobile.
- [ ] Funzioni, dati, API e formati di uscita originali sono conservati.
- [ ] I test disponibili sono superati senza chiamate AI reali.
- [ ] Non sono presenti credenziali o dati reali.
- [ ] La cartella restituita è completa e avviabile.
- [ ] `RIEPILOGO-MODIFICHE.md` è presente nella cartella principale.
- [ ] Non sono stati creati repository, commit, push o pull request.
